<?php 

$id = isset($_GET["id"]) ? $_GET["id"] : null;

$stedenRepository = new StedenRepository();
$stad = is_null($id) ? $stedenRepository->new() : $stedenRepository->find($id);

if (is_null($stad)) 
{   // we hebben de stad niet gevonden
    header("Location: error.html");
}

$stadForm = new StadForm();

if ($_SERVER["REQUEST_METHOD"] === "POST") 
{
    $stadForm->setPost($_POST);
    if ($stadForm->isValid()) 
    {
        $stadForm->update($stad);
        $stedenRepository->update($stad);
        header("Location: index.php");
    }
}

$action = is_null($id) ? "edit_stad.php" : "edit_stad.php?id=".$id;
$titel = is_null($id) ? "Creëer een nieuwe stad" : "Bewerk stad";
?>
<html>
<head>
    <title><?php echo $titel; ?></title>
    <style>
        .error { color: red; font-weight: bold;}
    </style>
</head>
<body>
    <h1><?php echo $titel; ?></h1>
    <form action="<?php echo $action; ?>" method="post">
        <p>
            <label for="naam">Naam: </label>
            <input type="text" id="naam" name="<?php echo StadForm::FIELD_NAAM; ?>" value="<?php echo $stad->getName(); ?>" placeholder="geef de naam van de stad">
        </p>
        <?php if ($stadForm->hasError(StadForm::FIELD_NAAM)): ?>
            <p class="error"><?php echo $stadForm->getError(StadForm::FIELD_NAAM); ?></p>
        <?php endif; ?>
        <p>
            <label for="land">Land: </label>
            <input type="text" id="land" name="<?php echo StadForm::FIELD_LAND; ?>" value="<?php echo $stad->getLand(); ?>" placeholder="geef de naam van de land">
        </p>
        <?php if ($stadForm->hasError(StadForm::FIELD_LAND)): ?>
            <p class="error"><?php echo $stadForm->getError(StadForm::FIELD_LAND); ?></p>
        <?php endif; ?>
        <p>
            <label for="aantal">Aantal inwoners: </label>
            <input type="text" id="aantal" name="<?php echo StadForm::FIELD_INWONERS; ?>" value="<?php echo $stad->getInwoners(); ?>" placeholder="geef het aantal inwoners">
        </p>
        <?php if ($stadForm->hasError(StadForm::FIELD_INWONERS)): ?>
            <p class="error"><?php echo $stadForm->getError(StadForm::FIELD_INWONERS); ?></p>
        <?php endif; ?>
        <p>
            <input type="submit" value="Verstuur">
        </p>
    </form>
</body>
</html>
