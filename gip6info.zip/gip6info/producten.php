<?php
session_start();
include("db_conn.php");
$sql = "SELECT * FROM Product order by ProductID desc";
$result = $conn->query($sql);
//var_dump($result);
$producten = [];
while($row = mysqli_fetch_assoc($result)) {
    $producten[] = $row;
 }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
</head>
<style>
     body {
            margin: 0px;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-image: url(img/27120_Oudenaarde_Oudenaarde_Koninklijk_Antheneum_Fortstraat_01.jpg);
            background-size: cover;
            background-repeat: no-repeat;
        }
        
        
        h1 {
            margin: 0;
            padding: 0 0 20px;
            text-align: center;
        }
        
        .right {
            float: right !important;
        }
        
        
        button {
            width: 200px;
            padding: 10px 0;
            border-radius: 15px;
            margin: 0 42px 15px;
            text-align: center;
            font-weight: bold;
            border: black;
            color: black;
            cursor: pointer;
            box-shadow: inset 0 0 0 0 #0bacc2;
            transition: ease-out 0.3s;
            font-size: 16px;
            font-weight: bold;
            outline: none;
        }
        
        button:hover {
            box-shadow: inset 200px 0 0 0 #0bacc2;
            color: white;
        }
               
        .navbar {
            background-color: #18222b;
            overflow: hidden;
        }
        
        .navbar a {
            color: white;
            display: block;
            padding: 14px 16px;
            font-size: 18px;
            float: left;
            text-decoration: none;
            text-align: center;
        }
        
        .navbar a:hover {
            background-color: #34495e;
        }

        .achtergrond {
            position: relative;
            width: 80%;
            height: 909px;
            background-color: rgba(202, 202, 202, 0.3);
            margin: auto;
            backdrop-filter: blur(5px);
            box-shadow: 3px 10px 10px 2px rgba(0,0,0,0.5);
        }
        
        .achtergrond h1 {
            padding-top: 25px;
            color: white;
            
            width: 100%;
            
        }
        
        .productalinea{
            
            width: 90%;
            height: 1800px;
            border: 1px solid pink;
            margin: auto;
            flex-wrap: wrap;
        }
        
        .product{
            border: 1px solid yellow;
            width: 300px;
            height: 700px;
            margin-top: 25px;
            margin-left: 45px;
            display: inline-block;
        }
        
        .foto{
            width: 302px;
            height: 250px;
            border: 1px solid aqua;
            
        }

        img{
            width: 302px;
            height: 250px;
        }
        .productnaam{
            margin-left: 5px;
            margin-top: 5px;
        }
</style>
<body>
    <div class="navbar">
        <a href="index.php">Home</a>
        <a href="producten.html">Producten</a>
        <a href="overons.html">Over ons</a>
        <a class="right" href="login.html">Login</a>
        <a class="right">Winkelmand</a>
    </div>
    <div class="achtergrond">

        <h1>Onze producten</h1>
        <div class="productalinea">
            <?php foreach ($producten as $product): ?>
            <div class="product">
                <div class="foto"><img src="img/<?php echo $product["Foto"]; ?>"></div>
                <div class="productnaam"><?php echo $product["Productnaam"] ?></div>
                <div><br><?php echo $product["Beschrijving"]; ?><br></div>
                <button type="button">Toevoegen</button>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</body>
</html>