<?php
namespace Model;
use Model\Stad;
use PDO;

class StedenRepository {

    private $steden = [];
    private $pdo;


    public function __construct() 
    {
        $host = "axel.go-ao.be";
        $username = "06InfoAxel";
        $password = "zwal8S@ndus";
        $database = "GIP4_webshop";
        $charset = "utf8mb4";

        $dsn = "mysql:host=$host;dbname=$database;charset=$charset";
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        try {
            $this->pdo = new PDO($dsn, $username, $password, $options);
        } catch (\PDOException $e) {
            throw new \PDOException($e->getMessage(), (int)$e->getCode());
}
    }
    public function findAll() {
        $steden = [];
        $stmt = $this->pdo->prepare("SELECT StadId, Naam, Land, Aantal from Steden");
        $stmt->execute();
        while ($result = $stmt->fetch()) 
        {
        $stad = new Stad($result["StadId"],$result["Naam"],$result["Land"],$result["Aantal"]);
        $steden[] = $stad;
        }
        return $steden;
        
    }

    public function find($id) {
        $stad = null;
        $stmt = $this->pdo->prepare("SELECT StadId, Naam, Land, Aantal from Steden WHERE StadId=:id");
        $stmt->execute(["id"=>$id]);
        while ($result = $stmt->fetch()) 
        {
        $stad = new Stad($result["StadId"],$result["Naam"],$result["Land"],$result["Aantal"]);
        }
        return $stad;
    }
    
    
    public function update($stad) {
        
        if (is_null($stad->getId())){
            //insert
            $stmt = $this->pdo->prepare("
                    INSERT INTO Steden (Naam, Land, Aantal)
                                VALUES (:naam,:land,:aantal)

                    ");

            $stmt->execute(["naam"=>$stad->getName(),
                            "land"=>$stad->getLand(),
                            "aantal"=>$stad->getInwoners()
                          ]);

            $this->steden[$this->nextIndex] = new Stad($this->nextIndex, $stad->getName(), $stad->getLand(), $stad->getInwoners());
            $this->nextIndex++;
        } else {
            //update
            $stmt = $this->pdo->prepare("
            Update Steden SET Naam=:naam, Land=:land, Aantal=:aantal WHERE StadId=:id
                              VALUES (:Naam,:Land,:Aantal)

            ");

    $stmt->execute(["id"=>$stad->getId(),
                    "naam"=>$stad->getName(),
                    "land"=>$stad->getLand(),
                    "aantal"=>$stad->getInwoners()
                  ]);
        }
        $this->save();
    }
    
    
    private function save() {
        $lines = [];
        foreach ($this->steden as $stad) {
            $lines[] = implode(",",[$stad->getId(), $stad->getName(), $stad->getLand(), $stad->getInwoners()]);
        }
        $content = implode(PHP_EOL,$lines);
        file_put_contents("data/steden.csv",$content);
    }

    public function new() {
        return new Stad(null,"","","");
    }

    public function delete($id)
    {
        $stmt = $this->pdo->prepare("DELETE from Steden  WHERE StadId=:id");
        $stmt->execute(["id"=>$id]);
    }
    
}